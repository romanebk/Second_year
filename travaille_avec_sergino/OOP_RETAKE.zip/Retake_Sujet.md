|     | B-OOP-400 |             | – C++ |     | Object-Oriented |     |     |
| --- | --------- | ----------- | ----- | --- | --------------- | --- | --- |
|     |           | Programming |       |     | Exam            |     |     |
Resit / Rattrapage
|     |     |     | Epitech | Bénin |      |     |     |
| --- | --- | --- | ------- | ----- | ---- | --- | --- |
|     |     |     | June    | 19,   | 2026 |     |     |
Preliminaries
| –     | Duration: | 4 hours                  |          |         |               |                 |     |
| ----- | --------- | ------------------------ | -------- | ------- | ------------- | --------------- | --- |
| –     | Language: | C++ (C++17               | minimum) |         |               |                 |     |
| –     | Focus     | on clean object-oriented |          | design, | extensibility | and modularity. |     |
| About | design    | patterns                 |          |         |               |                 |     |
Eachexercisestatesasetof design goals. Foreach,oneortwodesignpatterns
are strongly encouraged because they are the natural fit. They are not
imposed: any clean design that meets the stated goals is accepted, but you
must justify your choice at defense. A solution that meets the goals with
a poor, rigid design will be penalised regardless of whether a pattern name is
attached to it. Nothing beyond the Mandatory rules below is imposed: the
dynamic-plugin feature of Exercise 1 is a bonus. Each exercise is worth 30
| points;   | bonuses | add on top. |            |     |     |     |     |
| --------- | ------- | ----------- | ---------- | --- | --- | --- | --- |
| Mandatory |         | rules (all  | exercises) |     |     |     |     |
– Error messages go to standard error. A fatal error (bad usage, an
|     | unreadablerequiredresource)makestheprogramexitwithcode84; |             |     |     |     |     | with |
| --- | --------------------------------------------------------- | ----------- | --- | --- | --- | --- | ---- |
|     | no error                                                  | it exits 0. |     |     |     |     |      |
– In an interactive loop (Exercises 1 and 3), an error caused by a single
|     | input | line is reported | on standard | error | and the loop | continues; | end of |
| --- | ----- | ---------------- | ----------- | ----- | ------------ | ---------- | ------ |
|     | input | (CTRL+D) exits   | with status | 0.    |              |            |        |
– Noscalarexceptions: everythrownexceptioninheritsfromstd::exception.
– Behaviour that varies must sit behind an interface; do not branch on a
|     | type/phase | tag. |     |     |     |     |     |
| --- | ---------- | ---- | --- | --- | --- | --- | --- |
– Nomemoryleaks(valgrind/ASanclean). Theprogrammustnevercrash.
1

Project Structure and Makefile Usage
Same layout and rules as the main exam: a single unified Makefile at the root,
binaries ex1/ex2/ex3 at the root, plugins as .so in ./plugins/.
oop_exam/
Makefile
plugins/ # .so plugins consumed by ex1 (bonus)
src/
ex1/ # File System Size Calculator (Factory + Composite + plugins)
ex2/ # Report Section Builder (Builder + Decorator)
ex3/ # Upload Job Runner (Strategy + State)
Rules: make(all+plugins),make ex1|ex2|ex3,make plugins,make clean,
make fclean, make re.
Exercise 1 – File System Size Calculator (30 pts)
Encouraged patterns: Factory + Composite
Context
Build a small in-memory file system: directories contain files and other direc-
tories, and you can ask for the cumulative size of any entry. Unlike a one-shot
expressionyouevaluateonce,herethetreeisassembled incrementally,com-
mand by command, and stays addressable by path between commands. New
kinds of entries (a compressed archive, say) should be addable without editing
a central switch.
Design goals
– Computeadirectory’ssizerecursively,treatingafile(leaf)andadirectory
(composite) uniformly through size queries, while keeping the ability to
add children a capability only containers have. (Composite is encour-
aged.)
– Create an entry from a type name through a registry, so the set of entry
kinds stays open. (Factory by registration is encouraged.)
class IContainer; // forward-declared, see below
class IEntry {
public:
virtual ~IEntry() = default;
virtual long size() const = 0;
2

virtual const std::string &name() const = 0;
// Returns this entry as a container if it can hold children, else
// nullptr. A leaf (e.g. a file) returns nullptr; a directory returns
// itself. This is how the rest of the code tells the two apart
// WITHOUT a type tag or dynamic_cast.
virtual IContainer *asContainer() = 0;
};
class IContainer {
public:
virtual ~IContainer() = default;
virtual void addChild(std::unique_ptr<IEntry> child) = 0;
virtual IEntry *findChild(const std::string &name) const = 0;
virtual const std::vector<std::unique_ptr<IEntry>> &children() const = 0;
};
// The factory’s REGISTERED types are entry kinds; each Creator receives
// the new entry’s name and a single integer whose meaning depends on the
// type (raw byte size for "file"; ignored for "dir"):
// file -> a leaf, asContainer() returns nullptr
// dir -> a container, starts empty, asContainer() returns itself
class EntryFactory {
public:
using Creator =
std::function<std::unique_ptr<IEntry>(std::string name, long sizeArg)>;
void registerType(const std::string &type, Creator creator);
std::unique_ptr<IEntry> create(const std::string &type,
std::string name, long sizeArg) const;
std::vector<std::string> available() const; // for the ‘types‘ command
};
Provided code – path resolution
Navigatinganabsolutepath(/docs/img/logo.png)downthetreeisplumbing,
not design; it is given so you can focus on the entries themselves. Treat it as
already-written project code you may use as-is.
class FileSystem {
public:
FileSystem(); // creates an empty root directory "/"
// Splits "/docs/img/logo.png" into {"docs","img","logo.png"}.
static std::vector<std::string> splitPath(const std::string &path);
3

// Walks all but the last segment (each must already exist and be a
// container); returns the parent container and the last segment’s
// name, so the caller can addChild(...) or findChild(...) on it.
// Throws (an exam-style exception) if a segment is missing or not
// a container.
std::pair<IContainer *, std::string>
resolveParent(const std::string &path) const;
// Walks the FULL path and returns the entry at the end (the root
// itself for "/"). Throws if any segment along the way is missing.
IEntry *resolve(const std::string &path) const;
IContainer *root() const;
};
Required behaviour
– Built-in entry types: file (leaf, takes a byte size ≥ 0), dir (container,
the size argument is ignored).
– Commands read on stdin, one per line:
· mkdir <path> – creates an empty directory at <path>; its parent
must already exist.
· touch <path> <bytes> – creates a file of the given size at <path>;
its parent must already exist.
· size <path> – prints the entry’s size (a directory’s size is the sum
of all its descendants).
· tree <path> – prints the entry and, if it is a container, every de-
scendant indented by depth (one name per line; a file also shows its
size in parentheses – see example).
· types – lists the registered entry kinds (sorted); exit quits. End of
input (CTRL+D) exits with status 0.
– Creating an entry whose name already exists in its parent, or addressing
a path through something that is not a container, or addressing a path
thatdoesnotexist, isreportedonstandarderrorandtheloopcontinues
(no exit 84 for a bad command).
Output Example
> mkdir /docs
> touch /docs/readme.txt 120
> touch /docs/notes.txt 80
> mkdir /docs/img
> touch /docs/img/logo.png 4096
4

> size /docs
4296
> tree /docs
docs
readme.txt (120)
notes.txt (80)
img
logo.png (4096)
> touch /docs/readme.txt 1
Error: already exists: readme.txt
> size /nope
Error: no such file or directory: nope
> exit
Bonus – dynamic plugins (+10 pts)
Make new entry kinds loadable at runtime, without recompiling the core, from
.so files. This is where the plugin idea of the Arcade/Raytracer projects is
exercised.
– Add loadPlugins(const std::string &dir) that scans ./plugins/ at
startup,plusaload <path>command,bothusingdlopen/dlsym/dlclose
behind a libdl encapsulation. ldd ./ex1 must list none of the plugins.
– Each plugin exposes a C entry point:
extern "C" const char *entryType(); // "zip"
extern "C" IEntry *createEntry(const char *name, long sizeArg);
– loadPlugins registers each plugin’s type into the factory (it wraps the
C entry point in a Creator); the rest of the program still builds through
create, so built-in and plugin types are handled identically – including
through mkdir/touch if you choose to expose the type via those com-
mands, or a dedicated command of your own.
– Provide one plugin, e.g. zip: a leaf whose reported size() is half of
sizeArg(simulatinga2:1compressionratio),stilladdressableandlistable
exactly like a file.
loaded plugin: zip
> create /archive.zip zip 4000
> size /archive.zip
2000
The exact command used to create a plugin-provided entry (a generic create
<path> <type> <arg>, or extending touch) is up to you – justify your choice
at defense.
5

| Exercise   | 2         | – Report |         | Section     | Builder |     | (30 | pts) |     |
| ---------- | --------- | -------- | ------- | ----------- | ------- | --- | --- | ---- | --- |
| Encouraged | patterns: |          | Builder | + Decorator |         |     |     |      |     |
Context
A reporting tool assembles a section (a heading, a list of findings) before laying
it out for different outputs (numbered, indented, summarized). Unlike a simple
wrapper that only adds text before or after, here some augmentations must
look inside and transform the wrapped content’s lines, not just frame
them.
| Design | goals |     |     |     |     |     |     |     |     |
| ------ | ----- | --- | --- | --- | --- | --- | --- | --- | --- |
– Assemble a section from several optional parts (heading, finding lines)
| in a  | readable | way, | not through | a     | telescoping | constructor,    |     | and | reject an |
| ----- | -------- | ---- | ----------- | ----- | ----------- | --------------- | --- | --- | --------- |
| empty | section  | at   | build       | time. | (Builder    | is encouraged.) |     |     |           |
– Add numbering, indentation or a one-line summary by wrapping any
| widget, |                                            | stackable | in any | order,   | without   | modifying |      | the section | itself – |
| ------- | ------------------------------------------ | --------- | ------ | -------- | --------- | --------- | ---- | ----------- | -------- |
| and,    | for at                                     | least     | one of | them, by | rewriting | each      | line | the         | wrapped  |
| widget  | producedratherthanonlyaddinglinesaroundit. |           |        |          |           |           |      | (Decorator  | is       |
encouraged.)
| class IWidget |     | {   |     |     |     |     |     |     |     |
| ------------- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
public:
| virtual | ~IWidget() |     | = default; |     |     |     |     |     |     |
| ------- | ---------- | --- | ---------- | --- | --- | --- | --- | --- | --- |
virtual std::vector<std::string> render() const = 0; // lines of text
};
| class SectionBuilder |     |     | {   |     |     |     |     |     |     |
| -------------------- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
public:
| SectionBuilder           |     | &withHeading(const |     |          | std::string |     |         | &heading); |     |
| ------------------------ | --- | ------------------ | --- | -------- | ----------- | --- | ------- | ---------- | --- |
| SectionBuilder           |     | &addFinding(const  |     |          | std::string |     | &line); |            |     |
| std::unique_ptr<IWidget> |     |                    |     | build(); |             |     |         |            |     |
// build() THROWS (an exception inheriting std::exception) if no heading
// was set, or if zero findings were added -- a section must have both.
};
| // Effects | wrapping |     | an IWidget | (and | being | IWidget |     | themselves): |     |
| ---------- | -------- | --- | ---------- | ---- | ----- | ------- | --- | ------------ | --- |
// Numbered(std::unique_ptr<IWidget>)
// -- rewrites every line of the wrapped render() by prefixing it with
// its 1-based position, e.g. "Games" -> "1. Games". The heading line
// (the first line) is left untouched; only the lines AFTER it are
// renumbered. Must work no matter what is wrapped (a raw Section,
| //                                  | or  | another | decorator |     | already | applied). |     |     |     |
| ----------------------------------- | --- | ------- | --------- | --- | ------- | --------- | --- | --- | --- |
| // Indent(std::unique_ptr<IWidget>, |     |         |           |     | int     | amount)   |     |     |     |
6

// -- prefixes every line (heading included) with ‘amount‘ spaces.
| // Summary(std::unique_ptr<IWidget>, |     |     |     |     | std::string |     | label) |     |
| ------------------------------------ | --- | --- | --- | --- | ----------- | --- | ------ | --- |
// -- appends one line: "<label>: <N> item(s)" where N is the number of
// lines the wrapped widget produced, MINUS its heading line.
– Because an effect is itself an IWidget, effects compose. You must demon-
| strateat | least     | two stackedeffects,includingNumberedappliedontopof |              |     |      |              |         |          |
| -------- | --------- | -------------------------------------------------- | ------------ | --- | ---- | ------------ | ------- | -------- |
| another  | decorator | (proving                                           | it renumbers |     | what | it receives, | not the | original |
| raw      | lines).   |                                                    |              |     |      |              |         |          |
– Numbered and Summary must determine “how many lines are findings”
| without  | assuming | who          | produced |     | them | – they | only know | the first |
| -------- | -------- | ------------ | -------- | --- | ---- | ------ | --------- | --------- |
| rendered | line is  | the heading. |          |     |      |        |           |           |
| Output   | Example  |              |          |     |      |        |           |           |
| --- base | ---      |              |          |     |      |        |           |           |
Open Issues
| Build fails             | on ARM    |     |                    |     |     |     |     |     |
| ----------------------- | --------- | --- | ------------------ | --- | --- | --- | --- | --- |
| Memory leak             | in parser |     |                    |     |     |     |     |     |
| --- Summary("findings", |           |     | Numbered(section)) |     |     | --- |     |     |
Open Issues
| 1. Build                     | fails on  | ARM    |     |     |     |     |     |     |
| ---------------------------- | --------- | ------ | --- | --- | --- | --- | --- | --- |
| 2. Memory                    | leak in   | parser |     |     |     |     |     |     |
| findings:                    | 2 item(s) |        |     |     |     |     |     |     |
| --- Numbered(Indent(section, |           |        | 2)) | --- |     |     |     |     |
Open Issues
| 1. Build  | fails | on ARM    |     |     |     |     |     |     |
| --------- | ----- | --------- | --- | --- | --- | --- | --- | --- |
| 2. Memory | leak  | in parser |     |     |     |     |     |     |
In the last block, Indent ran first (every line got 2 leading spaces, heading in-
cluded),thenNumberedprefixedthepost-headinglineswiththeirindex–showing
| the indentation | is preserved, |          | not erased, | by      | the rewrite. |     |      |     |
| --------------- | ------------- | -------- | ----------- | ------- | ------------ | --- | ---- | --- |
| Exercise        | 3 –           | Upload   | Job         | Runner  |              | (30 | pts) |     |
| Encouraged      | patterns:     | Strategy |             | + State |              |     |      |     |
Context
Write a command-driven runner that processes a fixed queue of upload jobs
(each either bound to succeed or fail, known in advance for this exam). The
program reads commands on standard input. Two things vary, and this time
| they are | not fully | independent: |     |     |     |     |     |     |
| -------- | --------- | ------------ | --- | --- | --- | --- | --- | --- |
7

– Whatthecontrols(start,pause,stop,next)dodependsonwhetherthe
| runner | is idle, | running | or paused. |     |     |     |     |     |     |
| ------ | -------- | ------- | ---------- | --- | --- | --- | --- | --- | --- |
– Whethernextisevenallowedtoadvancepastafailedjobdependsonthe
currentfailurepolicy,switchableatruntime–sotheStrategy’sanswercan
| change       | what | the State | transition | does, | not | just which | index | comes | next. |
| ------------ | ---- | --------- | ---------- | ----- | --- | ---------- | ----- | ----- | ----- |
| Design goals |      |           |            |       |     |            |       |       |       |
– The same control behaves differently depending on the runner’s phase:
| pause | does nothing | when      | idle,   | next | keeps   | running | if it was | running    | but  |
| ----- | ------------ | --------- | ------- | ---- | ------- | ------- | --------- | ---------- | ---- |
| stays | paused       | if it was | paused, |      | resumes | from    | pause     | but starts | from |
start
| idle. Leteachphasehandlethecontrolsitselfinsteadofacentralswitch. |                 |     |     |     |     |     |     |     |     |
| ----------------------------------------------------------------- | --------------- | --- | --- | --- | --- | --- | --- | --- | --- |
| (State                                                            | is encouraged.) |     |     |     |     |     |     |     |     |
– Therulethatdecideswhetheradvancingpastthecurrentjob’soutcomeis
| allowed      | (strict:    | stop           | advancing    | on the       | first        | failure  | and move   | the          | runner  |
| ------------ | ----------- | -------------- | ------------ | ------------ | ------------ | -------- | ---------- | ------------ | ------- |
| to a blocked |             | sub-condition; |              | lenient:     | always       | advance  | regardless |              | of out- |
| come)        | must be     | switchable     |              | at runtime   | (a           | policy   | command)   | and          | open    |
| to new       | rules,      | without        | the          | policy class | ever         | touching |            | the runner’s |         |
| phase        | directly    | – it           | only answers | a            | yes/no       | question | that       | the          | Running |
| state        | asks before | acting.        | (Strategy    | is           | encouraged.) |          |            |              |         |
Interfaces
// STRATEGY: does ‘next‘ get to advance past the job at ‘current‘?
| class IFailurePolicy |     | {   |     |     |     |     |     |     |     |
| -------------------- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
public:
| virtual          | ~IFailurePolicy() |                    |         | = default;  |                  |          |        |        |         |
| ---------------- | ----------------- | ------------------ | ------- | ----------- | ---------------- | -------- | ------ | ------ | ------- |
| // jobs[current] |                   | is                 | the job | about       | to               | be left  | behind | by     | ‘next‘. |
| virtual          | bool              | allowAdvance(const |         |             | std::vector<Job> |          |        | &jobs, |         |
|                  |                   |                    |         | std::size_t |                  | current) | const  | =      | 0;      |
virtual std::string name() const = 0; // "strict" | "lenient"
};
| // Lenient | : always | returns |     | true. |     |     |     |     |     |
| ---------- | -------- | ------- | --- | ----- | --- | --- | --- | --- | --- |
// Strict : returns false if jobs[current] failed, true otherwise.
| class Runner; |     | // the | context | for BOTH | patterns |     |     |     |     |
| ------------- | --- | ------ | ------- | -------- | -------- | --- | --- | --- | --- |
// STATE: each control is handled per phase. The Running state is the ONLY
// one that consults the policy (via the Runner) when handling ‘next‘.
| class IRunnerState |     | {   |     |     |     |     |     |     |     |
| ------------------ | --- | --- | --- | --- | --- | --- | --- | --- | --- |
public:
| virtual | ~IRunnerState() |              | =   | default; |     |     |     |     |     |
| ------- | --------------- | ------------ | --- | -------- | --- | --- | --- | --- | --- |
| virtual | void            | start(Runner |     | &r) =    | 0;  |     |     |     |     |
| virtual | void            | pause(Runner |     | &r) =    | 0;  |     |     |     |     |
| virtual | void            | stop(Runner  |     | &r) =    | 0;  |     |     |     |     |
8

virtual void next(Runner &r) = 0;
virtual std::string name() const = 0; // "idle" | "running" | "paused" | "blocked"
};
class Runner {
public:
explicit Runner(std::vector<Job> jobs);
void setPolicy(std::unique_ptr<IFailurePolicy> policy); // runtime swap
void setState(std::unique_ptr<IRunnerState> state);
bool currentAllowsAdvance() const; // Running calls this; delegates to policy
// start()/pause()/stop()/next() delegate to the current state
// accessors for current index, jobs, policy name ...
};
Required behaviour
– Per-state semantics of the controls:
· Idle: start → Running (from current job); pause/stop ignored;
next moves the selection but stays Idle.
· Running: next asks the policy via currentAllowsAdvance(). If
true, it advances to the next job (wrapping at the end) and stays
Running. If false (only possible under strict, on a failed job), it
does not advance and the runner moves to Blocked instead. pause
→ Paused; stop → Idle; start ignored.
· Paused: start→Running(resume, nopolicycheck); stop→Idle;
next picks the next job without consulting the policy (manual
override) and stays Paused; pause ignored.
· Blocked: nextadvancespastthefailedjobandreturnstoRunning
(acknowledging the failure); stop → Idle; start/pause ignored.
– Commands read on stdin: start, pause, stop, next, policy <name>,
display, exit.
– Everytransportcommand(start/pause/stop/next)prints[state] job
afterwards – including when it was ignored. policy prints nothing
on success.
– An unknown policy or command is reported on standard error and the
loop continues. End of input (CTRL+D) stops with status 0.
Output Example
jobs: [0] avatar.png(ok) [1] backup.zip(fail) [2] logo.svg(ok) (policy = strict)
> start
[running] avatar.png
9

> next
| [running] | backup.zip |     |     |     |     |     |     |     |
| --------- | ---------- | --- | --- | --- | --- | --- | --- | --- |
> next
| [blocked] | backup.zip |     |     |     |     |     |     |     |
| --------- | ---------- | --- | --- | --- | --- | --- | --- | --- |
> next
| [running] | logo.svg |     |     |     |     |     |     |     |
| --------- | -------- | --- | --- | --- | --- | --- | --- | --- |
| > policy  | lenient  |     |     |     |     |     |     |     |
> stop
[idle] logo.svg
> start
| [running] | logo.svg |     |     |     |     |     |     |     |
| --------- | -------- | --- | --- | --- | --- | --- | --- | --- |
> pause
| [paused] | logo.svg |     |     |     |     |     |     |     |
| -------- | -------- | --- | --- | --- | --- | --- | --- | --- |
> next
| [paused] | avatar.png |     |     |     |     |     |     |     |
| -------- | ---------- | --- | --- | --- | --- | --- | --- | --- |
Note how the second next could not leave backup.zip behind under strict
(it failed), forcing Blocked; the third next then acknowledged it and resumed
| Running. | Also note | next | from Paused never | consults |     | the policy | at  | all. |
| -------- | --------- | ---- | ----------------- | -------- | --- | ---------- | --- | ---- |
Hint: astate’smethodisallowedtocallr.setState(...) onitself(thisishow
every transition above happens) – once you do, do not touch any of that state’s
own members afterwards, since the old state object is destroyed as soon as the
newoneisinstalled. Doingtheswapasthelaststatementofthemethod, asin
| the examples | above,   | sidesteps | the issue entirely. |     |     |     |     |     |
| ------------ | -------- | --------- | ------------------- | --- | --- | --- | --- | --- |
| Bonus        | (+5 pts) |           |                     |     |     |     |     |     |
– Add a new policy (e.g. halfwayStrict: lenient on the first half of the
| queue        | by index,  | strict      | from the         | midpoint | onward)    |         | without  | modifying |
| ------------ | ---------- | ----------- | ---------------- | -------- | ---------- | ------- | -------- | --------- |
| the          | runner or  | any state.  | Tip: a           | policy   | can answer | purely  | from     | (jobs,    |
| current)     | – it       | does not    | need to remember |          | anything   | between | calls.   |           |
| Time         | management |             | (indicative)     |          |            |         |          |           |
| – 0h00–0h10: | read       | everything, | lay down         | the      | interfaces | in      | headers. |           |
– 0h10–1h10: Exercise 1 (entries + factory + path commands; the plugin
| bonus | only if | time allows). |     |     |     |     |     |     |
| ----- | ------- | ------------- | --- | --- | --- | --- | --- | --- |
– 1h10–2h15: Exercise 2 (the section builder first, then the decorators –
| start        | with Numbered, |     | it is the trickiest). |        |          |         |        |          |
| ------------ | -------------- | --- | --------------------- | ------ | -------- | ------- | ------ | -------- |
| – 2h15–3h30: | Exercise       |     | 3 (the policies       | first, | then the | four    | runner | states). |
| – 3h30–4h00: | bonuses,       |     | valgrind/ASan,        | exit   | codes,   | cleanup | of the | turn-in. |
10
